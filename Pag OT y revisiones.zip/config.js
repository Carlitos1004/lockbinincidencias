// =========================================================================
// PEGA AQUÍ TUS 2 VALORES DE SUPABASE
// (Project Settings → API, en tu proyecto de supabase.com)
// =========================================================================
const SUPABASE_URL = "PEGA_AQUI_TU_PROJECT_URL";
const SUPABASE_ANON_KEY = "PEGA_AQUI_TU_ANON_PUBLIC_KEY";

const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
